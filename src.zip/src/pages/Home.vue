<template>
    <div>
      <TazeVaredin></TazeVaredin>
      <mavaneKhoroj></mavaneKhoroj>
      <HamCheshmi></HamCheshmi>
      <ChaneZani></ChaneZani>
      <TaminKonandegan></TaminKonandegan>
      <Jaygozinha></Jaygozinha>
      <EghdamatDolat></EghdamatDolat>
    </div>
</template>

<script setup>
import TazeVaredin from '@/components/Porter/TazeVaredin.vue'
import MavaneKhoroj from '@/components/Porter/MavaneKhoroj.vue'
import HamCheshmi from '@/components/Porter/HamCheshmi.vue'
import ChaneZani from '@/components/Porter/ChaneZani.vue'
import TaminKonandegan from '@/components/Porter/TaminKonandegan.vue'
import Jaygozinha from '@/components/Porter/Jaygozinha.vue'
import EghdamatDolat from '@/components/Porter/EghdamatDolat.vue'

</script>

<style>

</style>